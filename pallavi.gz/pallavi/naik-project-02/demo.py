print("a1")
