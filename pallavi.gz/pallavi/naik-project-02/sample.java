class Hello{
	public static void main(String [])
	{
		println("hello java")
        }
}

